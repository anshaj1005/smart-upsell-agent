// Smart Upsell Agent - Enhanced JavaScript
// AI-Powered Revenue Optimization Platform

let users = [];
let analytics = {};
let planChart = null;

// Enhanced initialization
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing Enhanced Smart Upsell Agent...');
    initializeEnhancedApp();
});

async function initializeEnhancedApp() {
    try {
        showLoading();
        await Promise.all([
            loadAnalytics(),
            loadUsers()
        ]);
        initializeCharts();
        hideLoading();
        console.log('✅ Enhanced app initialized successfully');
    } catch (error) {
        console.error('❌ Initialization failed:', error);
        showAlert('Failed to initialize application', 'danger');
    }
}

// Enhanced analytics loading
async function loadAnalytics() {
    try {
        const response = await fetch('/api/enhanced-analytics');
        analytics = await response.json();

        updateDashboardStats(analytics);

        console.log('📊 Enhanced analytics loaded:', analytics);

    } catch (error) {
        console.error('❌ Error loading analytics:', error);
    }
}

function updateDashboardStats(data) {
    // Update main cards
    updateElement('total-users', data.total_users || 0);
    updateElement('upsells-sent', data.total_upsells_sent || 0);
    updateElement('avg-probability', `${(data.conversion_rate || 0)}%`);
    updateElement('revenue-impact', `$${(data.revenue_impact || 0).toFixed(0)}`);

    // Update hero stats
    updateElement('hero-users', data.total_users || 0);
    updateElement('hero-conversions', `${(data.conversion_rate || 0)}%`);
    updateElement('hero-revenue', `$${(data.revenue_impact || 0).toFixed(0)}`);
    updateElement('hero-roi', `${(data.roi || 0)}x`);
}

function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

// Enhanced user loading with AI predictions
async function loadUsers() {
    try {
        const response = await fetch('/api/users');
        users = await response.json();

        displayEnhancedUsers(users);

        console.log(`👥 Loaded ${users.length} users with enhanced AI analysis`);

    } catch (error) {
        console.error('❌ Error loading users:', error);
        document.getElementById('users-tbody').innerHTML = `
            <tr><td colspan="5" class="text-center text-danger py-4">
                <i class="fas fa-exclamation-triangle me-2"></i>Error loading users
            </td></tr>
        `;
    }
}

function displayEnhancedUsers(userList) {
    const tbody = document.getElementById('users-tbody');
    if (!tbody) return;

    if (userList.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="5" class="text-center py-5">
                <div>
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No Users Found</h5>
                    <p class="text-muted">Load sample data to get started with AI-powered upselling</p>
                    <button class="btn btn-primary" onclick="loadSampleData()">
                        <i class="fas fa-database me-1"></i>Load Demo Data
                    </button>
                </div>
            </td></tr>
        `;
        return;
    }

    const usersHtml = userList.map(user => createEnhancedUserRow(user)).join('');
    tbody.innerHTML = usersHtml;
}

function createEnhancedUserRow(user) {
    const recommendation = user.recommendation || {};
    const churnLevel = getChurnRiskLevel(user.churn_risk || 0);
    const segmentBadge = getSegmentBadge(recommendation.segment || 'Unknown');
    const probabilityClass = getProbabilityClass(user.upsell_probability || 0);

    return `
        <tr class="user-row" data-user-id="${user.user_id}">
            <td>
                <div class="d-flex align-items-center">
                    <div class="user-avatar me-3">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" 
                             style="width: 40px; height: 40px;">
                            ${user.name.charAt(0)}
                        </div>
                    </div>
                    <div>
                        <h6 class="mb-1">${user.name}</h6>
                        <small class="text-muted">
                            <i class="fas fa-envelope me-1"></i>${user.email}
                        </small>
                        <br>
                        <small class="text-muted">
                            <i class="fas fa-calendar me-1"></i>
                            ${Math.round(user.days_since_signup || 0)} days active
                        </small>
                    </div>
                </div>
            </td>
            <td>
                <div class="plan-info">
                    ${getPlanBadge(user.current_plan_tier)}
                    <div class="mt-1">
                        <small class="text-muted d-block">
                            <i class="fas fa-chart-bar me-1"></i>
                            Usage: ${(user.feature_usage_score || 0).toFixed(0)}%
                        </small>
                        <small class="text-muted d-block">
                            <i class="fas fa-mouse me-1"></i>
                            ${user.login_frequency || 0} logins/month
                        </small>
                        <small class="text-muted d-block">
                            <i class="fas fa-dollar-sign me-1"></i>
                            LTV: $${(user.ltv_prediction || 0).toFixed(0)}
                        </small>
                    </div>
                </div>
            </td>
            <td>
                <div class="ai-analysis">
                    ${segmentBadge}
                    <div class="mt-2">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small>Upsell Probability</small>
                            <span class="badge bg-${probabilityClass}">
                                ${(user.upsell_probability || 0).toFixed(1)}%
                            </span>
                        </div>
                        <div class="progress mb-2" style="height: 4px;">
                            <div class="progress-bar bg-${probabilityClass}" 
                                 style="width: ${user.upsell_probability || 0}%"></div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small>Churn Risk</small>
                            ${churnLevel.badge}
                        </div>
                        <div class="progress" style="height: 4px;">
                            <div class="progress-bar bg-${churnLevel.class}" 
                                 style="width: ${user.churn_risk || 0}%"></div>
                        </div>
                    </div>
                </div>
            </td>
            <td>
                <div class="recommendation-card">
                    <div class="d-flex align-items-center mb-2">
                        ${getUrgencyIcon(recommendation.urgency || 'low')}
                        <strong class="ms-2">${recommendation.recommended_plan || 'Professional Plan'}</strong>
                    </div>
                    <p class="small text-muted mb-2">
                        ${(recommendation.message || 'Ready for upgrade').substring(0, 80)}...
                    </p>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-success">
                            <i class="fas fa-chart-line me-1"></i>
                            Success: ${(user.upsell_probability || 0).toFixed(0)}%
                        </small>
                        <small class="text-info">
                            Revenue: $${((user.upsell_probability || 0) * 100).toFixed(0)}
                        </small>
                    </div>
                </div>
            </td>
            <td>
                <div class="btn-group-vertical btn-group-sm" role="group">
                    <button class="btn btn-success" onclick="openEnhancedUpsellModal('${user.user_id}')">
                        <i class="fas fa-rocket me-1"></i>Send Upsell
                    </button>
                    ${user.churn_risk > 60 ? `
                    <button class="btn btn-outline-warning btn-sm mt-1" onclick="preventChurn('${user.user_id}')">
                        <i class="fas fa-life-ring me-1"></i>Retain
                    </button>
                    ` : ''}
                </div>
            </td>
        </tr>
    `;
}

// Enhanced utility functions
function getChurnRiskLevel(churnRisk) {
    if (churnRisk > 70) return { badge: '<span class="badge bg-danger">High Risk</span>', class: 'danger' };
    if (churnRisk > 40) return { badge: '<span class="badge bg-warning">Medium Risk</span>', class: 'warning' };
    return { badge: '<span class="badge bg-success">Low Risk</span>', class: 'success' };
}

function getSegmentBadge(segment) {
    const segmentColors = {
        'Power Users': 'primary',
        'Growing Teams': 'success',
        'Casual Users': 'info',
        'Enterprise Ready': 'warning',
        'New Adopters': 'secondary'
    };
    const color = segmentColors[segment] || 'secondary';
    return `<span class="badge bg-${color}">${segment}</span>`;
}

function getProbabilityClass(probability) {
    if (probability > 80) return 'success';
    if (probability > 60) return 'warning';
    return 'secondary';
}

function getPlanBadge(tier) {
    const plans = {
        1: { name: 'Basic', class: 'secondary' },
        2: { name: 'Professional', class: 'primary' },
        3: { name: 'Enterprise', class: 'success' },
        4: { name: 'Enterprise Plus', class: 'warning' }
    };
    const plan = plans[tier] || plans[1];
    return `<span class="badge bg-${plan.class}">${plan.name}</span>`;
}

function getUrgencyIcon(urgency) {
    const urgencyIcons = {
        'critical': '<i class="fas fa-exclamation-triangle text-danger"></i>',
        'high': '<i class="fas fa-arrow-up text-warning"></i>',
        'medium': '<i class="fas fa-arrow-right text-info"></i>',
        'low': '<i class="fas fa-arrow-down text-secondary"></i>'
    };
    return urgencyIcons[urgency] || urgencyIcons['low'];
}

// Enhanced modal functions
function openEnhancedUpsellModal(userId) {
    const user = users.find(u => u.user_id === userId);
    if (!user) return;

    window.currentUserId = userId;
    const modal = new bootstrap.Modal(document.getElementById('upsellModal'));

    const modalContent = createEnhancedUpsellPreview(user);
    document.getElementById('upsell-message-preview').innerHTML = modalContent;

    modal.show();
}

function createEnhancedUpsellPreview(user) {
    const recommendation = user.recommendation || {};

    return `
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">
                            <i class="fas fa-user-circle me-2"></i>Target User Profile
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <strong>${user.name}</strong><br>
                                <small class="text-muted">${user.email}</small><br>
                                <small class="text-muted">${Math.round(user.days_since_signup || 0)} days active</small>
                            </div>
                            <div class="col-6">
                                ${getPlanBadge(user.current_plan_tier)}<br>
                                ${getSegmentBadge(recommendation.segment || 'Unknown')}<br>
                                <small class="text-muted">LTV: $${(user.ltv_prediction || 0).toFixed(0)}</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0">
                            <i class="fas fa-robot me-2"></i>AI-Generated Message
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="message-preview p-3 border rounded bg-light">
                            <p class="mb-2"><strong>Subject:</strong> ${getSubjectLine(recommendation)}</p>
                            <hr>
                            <p>${recommendation.message || 'Personalized upsell message will appear here.'}</p>

                            <div class="mt-3 p-2 border rounded bg-white">
                                <strong>✨ Upgrade to ${recommendation.recommended_plan}</strong><br>
                                <small class="text-muted">Unlock advanced features perfect for ${recommendation.segment}</small>
                                <div class="mt-2">
                                    <button class="btn btn-primary btn-sm">Upgrade Now</button>
                                    <button class="btn btn-outline-secondary btn-sm">Learn More</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h6 class="mb-0">
                            <i class="fas fa-chart-line me-2"></i>AI Predictions
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Success Probability:</span>
                                <strong class="text-success">${(user.upsell_probability || 0).toFixed(1)}%</strong>
                            </div>
                            <div class="progress mt-1" style="height: 6px;">
                                <div class="progress-bar bg-success" style="width: ${user.upsell_probability || 0}%"></div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Churn Risk:</span>
                                <strong class="text-${user.churn_risk > 50 ? 'danger' : 'warning'}">${(user.churn_risk || 0).toFixed(1)}%</strong>
                            </div>
                            <div class="progress mt-1" style="height: 6px;">
                                <div class="progress-bar bg-${user.churn_risk > 50 ? 'danger' : 'warning'}" style="width: ${user.churn_risk || 0}%"></div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Revenue Impact:</span>
                                <strong class="text-primary">$${((user.upsell_probability || 0) * 100).toFixed(0)}</strong>
                            </div>
                        </div>

                        <hr>

                        <div class="text-center">
                            <div class="h4 text-info mb-1">${recommendation.urgency?.toUpperCase() || 'LOW'}</div>
                            <small class="text-muted">Campaign Urgency</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function getSubjectLine(recommendation) {
    const urgency = recommendation.urgency || 'low';
    const segment = recommendation.segment || 'User';

    const subjectLines = {
        'critical': `🚨 Urgent: Perfect upgrade opportunity for ${segment}`,
        'high': `🚀 Ready to scale? Upgrade opportunity inside!`,
        'medium': `💡 ${segment} love these advanced features`,
        'low': `✨ Discover what's possible with ${recommendation.recommended_plan}`
    };

    return subjectLines[urgency] || subjectLines['low'];
}

// Enhanced upsell sending
async function sendEnhancedUpsell(userId, channel = 'in-app') {
    const btn = document.getElementById('confirm-upsell');
    if (btn) {
        const originalText = btn.innerHTML;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Sending...';
        btn.disabled = true;

        try {
            const response = await fetch(`/api/user/${userId}/upsell`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    channel: channel,
                    campaign_id: 'dashboard_manual_' + Date.now()
                })
            });

            const result = await response.json();

            if (result.success) {
                showAlert(`🚀 Enhanced upsell sent via ${channel}! Success probability: ${result.insights?.success_probability}`, 'success');
                bootstrap.Modal.getInstance(document.getElementById('upsellModal')).hide();
                await refreshUsers();
            } else {
                showAlert('❌ Failed to send upsell', 'danger');
            }
        } catch (error) {
            console.error('Error sending enhanced upsell:', error);
            showAlert('❌ Error sending upsell', 'danger');
        } finally {
            if (btn) {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        }
    }
}

// Enhanced chart initialization
function initializeCharts() {
    const planCtx = document.getElementById('planChart');
    if (planCtx) {
        planChart = new Chart(planCtx, {
            type: 'doughnut',
            data: {
                labels: ['Basic', 'Professional', 'Enterprise', 'Enterprise Plus'],
                datasets: [{
                    data: [0, 0, 0, 0],
                    backgroundColor: ['#6c757d', '#0d6efd', '#198754', '#ffc107']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        updatePlanChart();
    }
}

function updatePlanChart() {
    if (!planChart || !analytics.plan_distribution) return;

    const planData = [
        analytics.plan_distribution[1] || 0,
        analytics.plan_distribution[2] || 0,
        analytics.plan_distribution[3] || 0,
        analytics.plan_distribution[4] || 0
    ];

    planChart.data.datasets[0].data = planData;
    planChart.update();
}

// Enhanced load sample data function
async function loadSampleData() {
    const btn = event.target;
    const originalText = btn.innerHTML;

    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Loading Enhanced Data...';
    btn.disabled = true;

    try {
        const response = await fetch('/add_enhanced_sample_data');
        const result = await response.json();

        if (result.success) {
            showAlert('🎉 Enhanced demo data loaded! AI is analyzing users with advanced features...', 'success');
            setTimeout(async () => {
                await refreshUsers();
                await loadAnalytics();
                showAlert('✨ AI analysis complete! Ready for advanced upselling with segmentation and churn prediction.', 'info');
            }, 1500);
        } else {
            showAlert('❌ Error loading enhanced demo data', 'danger');
        }
    } catch (error) {
        console.error('Error loading enhanced sample data:', error);
        showAlert('❌ Error loading enhanced demo data', 'danger');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// Enhanced utility functions
async function refreshUsers() {
    showLoading();
    await loadUsers();
    await loadAnalytics();
    hideLoading();
    showAlert('🔄 User data refreshed with latest AI predictions', 'info');
}

function preventChurn(userId) {
    showAlert(`🛡️ Launching churn prevention campaign for user ${userId}`, 'warning');
}

// Enhanced loading and alerts
function showLoading() {
    const loadingElements = document.querySelectorAll('.loading-state');
    loadingElements.forEach(el => el.style.display = 'block');
}

function hideLoading() {
    const loadingElements = document.querySelectorAll('.loading-state');
    loadingElements.forEach(el => el.style.display = 'none');
}

function showAlert(message, type = 'info', duration = 4000) {
    const existingAlerts = document.querySelectorAll('.alert-notification');
    existingAlerts.forEach(alert => alert.remove());

    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-notification position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px; backdrop-filter: blur(10px);';
    alertDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : type === 'warning' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
            <span>${message}</span>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, duration);
}

// Event handlers
document.addEventListener('click', function(e) {
    if (e.target.id === 'confirm-upsell') {
        e.preventDefault();
        if (window.currentUserId) {
            sendEnhancedUpsell(window.currentUserId);
        }
    }
});

// Enhanced global styles
const enhancedStyles = document.createElement('style');
enhancedStyles.textContent = `
    .user-row:hover {
        background-color: #f8f9fa;
        transition: background-color 0.2s ease;
    }

    .activity-item {
        border-left: 3px solid #4f46e5;
        transition: all 0.2s ease;
    }

    .activity-item:hover {
        background-color: #e9ecef !important;
        border-left-color: #0d6efd;
    }

    .recommendation-card:hover {
        border-left-color: #198754;
        background-color: rgba(25, 135, 84, 0.05);
    }
`;

document.head.appendChild(enhancedStyles);

console.log('✅ Enhanced Smart Upsell Agent JavaScript loaded successfully');
